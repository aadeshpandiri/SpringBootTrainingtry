package com.example.payment.controller;

import com.example.payment.entity.Payment;
import com.example.payment.service.PaymentService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/payments")
public class PaymentController {
    private final PaymentService paymentService;

    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    @PostMapping
    public ResponseEntity<?> pay(@RequestBody Payment payment) {
        if (payment.getAmount() != null && payment.getAmount() < 0) {
            throw new RuntimeException("Simulated payment failure");
        }
        Payment p = paymentService.makePayment(payment);
        return ResponseEntity.ok(p);
    }

    @PostMapping("/{id}/refund")
    public ResponseEntity<?> refund(@PathVariable("id") Long id) {
        paymentService.refund(id);
        return ResponseEntity.ok().build();
    }
}
