package com.example.orchestrator.controller;

import com.example.orchestrator.service.SagaService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/sagas")
public class SagaController {
    private final SagaService sagaService;

    public SagaController(SagaService sagaService) {
        this.sagaService = sagaService;
    }

    @PostMapping("/orders")
    public ResponseEntity<?> createOrderSaga(@RequestBody Map<String, Object> payload) {
        return ResponseEntity.ok(sagaService.startOrderSaga(payload));
    }
}
