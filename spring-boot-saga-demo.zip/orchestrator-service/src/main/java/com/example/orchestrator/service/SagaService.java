package com.example.orchestrator.service;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

@Service
public class SagaService {
    private final RestTemplate restTemplate = new RestTemplate();

    private final String ORDER_URL = "http://localhost:8081/orders";
    private final String ORDER_CANCEL_URL = "http://localhost:8081/orders/{id}/cancel";
    private final String PAYMENT_URL = "http://localhost:8082/payments";
    private final String PAYMENT_REFUND_URL = "http://localhost:8082/payments/{id}/refund";

    //@Transactional( propagation =Propagation.MANDATORY)
    @Transactional
    public Map<String, Object> startOrderSaga(Map<String, Object> payload) {
        Map<String, Object> result = new HashMap<>();
        ResponseEntity<Map> orderResp = restTemplate.postForEntity(ORDER_URL, payload, Map.class);
        Map order = orderResp.getBody();
        result.put("order", order);
        try {
            Map<String, Object> paymentReq = new HashMap<>();
            paymentReq.put("orderId", order.get("id"));
            paymentReq.put("amount", payload.get("amount"));

            ResponseEntity<Map> payResp = restTemplate.postForEntity(PAYMENT_URL, paymentReq, Map.class);
            Map payment = payResp.getBody();
            result.put("payment", payment);

            result.put("status", "COMPLETED");
            return result;
        } catch (Exception ex) {
            try {
                restTemplate.exchange(ORDER_CANCEL_URL, HttpMethod.POST, HttpEntity.EMPTY, Void.class, order.get("id"));
                result.put("compensation", "ORDER_CANCELLED");
            } catch (Exception ex2) {
                result.put("compensation", "ORDER_CANCEL_FAILED: " + ex2.getMessage());
            }
            result.put("status", "FAILED");
            result.put("error", ex.getMessage());
            return result;
        }
    }
}
