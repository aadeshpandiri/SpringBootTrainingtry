package com.example.cache.service;

import com.example.cache.model.User;
import org.springframework.cache.annotation.*;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
@CacheConfig(cacheNames = "users") // class-level shared cache name
public class UserService {

    // simple in-memory map to simulate DB
    private final Map<Long, User> db = new HashMap<>();

    public UserService() {
        // seed some users
        db.put(1L, new User(1L, "Alice"));
        db.put(2L, new User(2L, "Bob"));
    }

    // Simulated slow DB call that populates cache on first call
    @Cacheable(key = "#id")
    public User getUser(Long id) {
        return getUserFromDb(id);
    }

    // Example of updating cache after modifying the entity
    @CachePut(key = "#user.id")
    public User updateUser(User user) {
        // update the "DB"
        db.put(user.getId(), user);
        // return updated user which will be placed into cache because of @CachePut
        return user;
    }

    // Evict single user from cache
    @CacheEvict(key = "#id")
    public void deleteUser(Long id) {
        // remove from "DB"
        db.remove(id);
    }

    // Evict all entries in the 'users' cache
    @CacheEvict(allEntries = true)
    public void evictAllUsers() {
        // nothing else to do; cache entries are removed by annotation
    }

    // Use @Caching to apply multiple cache operations on one method
    // This method creates a new user and both puts it into the 'users' cache
    // and evicts the 'userList' cache (imagine there's a separate cache for lists)
    @Caching(
            put = {@CachePut(key = "#user.id")},
            evict = {@CacheEvict(cacheNames = "userList", allEntries = true)}
    )
    public User createUser(User user) {
        // assign id if missing (simple simulation)
        if (user.getId() == null) {
            long newId = db.keySet().stream().mapToLong(Long::longValue).max().orElse(0L) + 1;
            user.setId(newId);
        }
        db.put(user.getId(), user);
        return user;
    }

    // internal simulated DB access with delay to show caching effect
    private User getUserFromDb(Long id) {
        try {
            Thread.sleep(1000); // simulate slow DB
        } catch (InterruptedException ignored) {}
        System.out.println("[DB] loading user " + id);
        return db.get(id);
    }
}
