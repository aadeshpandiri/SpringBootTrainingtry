# Spring Boot Cache Demo (Spring Boot 3.5.x)

This project demonstrates Spring Cache annotations in a minimal Spring Boot 3.5.x application:
`@Cacheable`, `@CachePut`, `@CacheEvict`, `@Caching`, and `@CacheConfig`.

## What this repo contains
- A simple Spring Boot app (`CacheDemoApplication`) with caching enabled (`@EnableCaching`).
- `UserService` showing examples of:
  - `@Cacheable` to populate/read cache
  - `@CachePut` to update cache when updating an entity
  - `@CacheEvict` to evict single or all cache entries
  - `@Caching` to run multiple cache operations from a single method
  - `@CacheConfig` to set default cache names at class level
- `UserController` exposing REST endpoints for manual testing.
- A Postman collection (`postman_cache_demo_collection.json`) with example requests for basic caching scenarios.

## Prerequisites
- Java 17
- Maven 3.6+
- (Optional) Postman or any HTTP client

## Run the app
```bash
mvn clean package
mvn spring-boot:run
```
The app will run at `http://localhost:8080` by default.

## Endpoints & caching behavior
- `GET /api/users/{id}`
  - First call for an id triggers a simulated slow DB call (~1s) and populates the `users` cache.
  - Subsequent calls for the same id return the cached value immediately.
- `POST /api/users`
  - Creates a user (if `id` omitted it's auto-assigned) and uses `@Caching` to `@CachePut` the `users` cache for the new id and evict an imaginary `userList` cache.
- `PUT /api/users`
  - Updates a user and uses `@CachePut` to update the cached value for the user's id.
- `DELETE /api/users/{id}`
  - Deletes the user and `@CacheEvict` removes the cached entry for that id.
- `POST /api/users/evict-all`
  - Evicts all entries from the `users` cache (`@CacheEvict(allEntries = true)`).

## Quick manual tests (curl)
1. First GET (populates cache, ~1s):
   ```bash
   curl -sS http://localhost:8080/api/users/1 -w "\n"
   ```
2. Second GET (cached, immediate):
   ```bash
   curl -sS http://localhost:8080/api/users/1 -w "\n"
   ```
3. Update user (updates cache):
   ```bash
   curl -sS -X PUT http://localhost:8080/api/users -H 'Content-Type: application/json' -d '{"id":1,"name":"Alice Updated"}' -w "\n"
   ```
4. Delete user (evicts cache for id 1):
   ```bash
   curl -sS -X DELETE http://localhost:8080/api/users/1 -w "\n"
   ```
5. Evict all users:
   ```bash
   curl -sS -X POST http://localhost:8080/api/users/evict-all -w "\n"
   ```

## Postman collection — what it includes
The bundled Postman collection includes requests for:
- GET user (first time / cached)
- Create user (POST)
- Update user (PUT)
- Delete user (DELETE)
- Evict all (POST)

Use the collection variable `baseUrl` (default `http://localhost:8080`).

## Next steps / optional improvements
- Replace the default `ConcurrentMapCacheManager` with a production cache like Redis or Caffeine.
- Add Micrometer metrics to measure cache hits/misses.
- Add automated integration tests that assert cache timings and behavior.

## License

MIT

