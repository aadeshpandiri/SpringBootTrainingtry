package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.service.MessageService;

@RestController
public class MessageController {
	@Autowired
	MessageService messageService;
	//http://localhost:7777/fetchmessage
	@GetMapping("/fetchmessage")
	public String getMessage() {
		return messageService.getMessage();
		
		
	}

}
