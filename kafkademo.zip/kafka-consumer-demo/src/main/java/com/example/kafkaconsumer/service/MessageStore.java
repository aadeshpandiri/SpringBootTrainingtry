package com.example.kafkaconsumer.service;

import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Service
public class MessageStore {
    private final List<SimpleMessage> messages = Collections.synchronizedList(new ArrayList<>());

    public void add(SimpleMessage msg) { messages.add(msg); }
    public List<SimpleMessage> getAll() { return new ArrayList<>(messages); }
    public void clear() { messages.clear(); }
}
