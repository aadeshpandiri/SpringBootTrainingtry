package com.example.kafkaconsumer.controller;

import com.example.kafkaconsumer.service.MessageStore;
import com.example.kafkaconsumer.service.SimpleMessage;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/messages")
public class MessageController {

    private final MessageStore messageStore;

    public MessageController(MessageStore messageStore) {
        this.messageStore = messageStore;
    }

    @GetMapping("/received")
    public ResponseEntity<List<SimpleMessage>> received() {
        return ResponseEntity.ok(messageStore.getAll());
    }

    @PostMapping("/received/clear")
    public ResponseEntity<Void> clear() {
        messageStore.clear();
        return ResponseEntity.noContent().build();
    }
}
