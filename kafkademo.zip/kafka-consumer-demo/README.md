# Kafka Consumer Demo (Spring Boot 3.5.x)

This project is a minimal Spring Boot application that consumes messages from Kafka using Spring Cloud Stream (Kafka binder).
It listens to topic `demo-topic` and stores received messages in memory for inspection via REST endpoints.

## Important files
- `src/main/java/.../KafkaConsumerDemoApplication.java` — Spring Boot entrypoint
- `src/main/java/.../service/MessageConsumerConfig.java` — Consumer bean (function)
- `src/main/java/.../service/MessageStore.java` — in-memory store of received messages
- `src/main/java/.../controller/MessageController.java` — REST endpoints to view/clear messages
- `application.properties` — contains binder configuration (uses ${KAFKA_BROKERS} env var)

## Run locally (app on host) with Docker Compose Kafka from your other project
1. Ensure your Kafka stack is running (from previous project) and exposes host broker: `localhost:9092`.
2. Build and run this app locally:
   ```bash
   mvn clean package -DskipTests
   mvn spring-boot:run
   ```
   or run jar:
   ```bash
   java -jar target/kafka-consumer-demo-0.0.1-SNAPSHOT.jar
   ```
3. The app runs on http://localhost:8081. Endpoints:
   - `GET /api/messages/received` — list consumed messages
   - `POST /api/messages/received/clear` — clear the store

## Run inside Docker Compose (same network as Kafka)
If you prefer to run this consumer as a container inside the same compose network as Kafka (recommended for isolation):

1. Build the jar locally: `mvn clean package -DskipTests`
2. Add a service to your Docker Compose file (example):
   ```yaml
   consumer:
     build: ./kafka-consumer-demo
     dockerfile: Dockerfile
     environment:
       - KAFKA_BROKERS=kafka:29092
     depends_on:
       - kafka
   ```
3. Ensure `KAFKA_BROKERS` env points to the internal broker (kafka:29092).

## Postman collection
A simple Postman collection `postman_consumer_collection.json` is  for convenience (GET /api/messages/received, POST clear).

