# Spring Cloud Stream (Kafka) Demo — Spring Boot 3.5.x

This sample project demonstrates messaging with **Kafka** using **Spring Cloud Stream** (functional programming model).

## What it contains

- Spring Boot app with a REST controller to publish messages to Kafka via `StreamBridge`.
- A `Consumer<SimpleMessage>` bean that receives messages from Kafka and stores them in-memory (for demo/inspection).
- `docker-compose.yml` to run Zookeeper + Kafka locally.
- Detailed `README` instructions and a Postman collection for quick testing.

## Quick start (Docker Compose)

1. Build the project:

```bash
mvn clean package -DskipTests
```

2. Start Kafka + Zookeeper using Docker Compose (from project root):

```bash
docker compose up -d
```

Wait a few seconds for Kafka to become ready.

3. Run the Spring Boot app (locally):

```bash
mvn spring-boot:run
```

Alternatively build the jar and run:
```bash
java -jar target/spring-boot-kafka-stream-demo-0.0.1-SNAPSHOT.jar
```

The app listens on `http://localhost:8080`.

## Application configuration

See `src/main/resources/application.properties` — important settings:

- `spring.cloud.stream.bindings.publish-out-0.destination=demo-topic`
  - The binding name `publish-out-0` maps to a destination (Kafka topic) `demo-topic`.
- `spring.cloud.stream.bindings.messageConsumer-in-0.destination=demo-topic`
  - The consumer `messageConsumer` is bound to the same topic.
- `spring.cloud.stream.kafka.binder.brokers=localhost:9092`
  - Points to the Kafka broker launched by Docker Compose.

## Endpoints (Postman)

- `POST /api/messages/publish` — Publish a message to Kafka.
  - Body: `{ "payload": "hello world" }` — `id` is optional.
- `GET /api/messages/received` — Returns messages consumed by the app (in-memory store).
- `POST /api/messages/received/clear` — Clears the in-memory store.

## Postman testing scenarios

1. **Publish a message**
   - `POST http://localhost:8080/api/messages/publish`
   - Body: `{ "payload": "hello from postman" }`
   - Expect: 200 OK and returned message with `id` and `createdAt`.

2. **Check consumed messages**
   - `GET http://localhost:8080/api/messages/received`
   - Expect: List containing the published message (consumer may take a short moment).

3. **Clear store**
   - `POST http://localhost:8080/api/messages/received/clear`
   - Expect: 204 No Content

## Creating the Kafka topic (optional)

The demo uses topic `demo-topic`. Kafka's auto-topic creation is usually enabled in the image above; if not, create it manually:

```bash
docker exec -it <kafka-container-name> kafka-topics --create --topic demo-topic --bootstrap-server localhost:9092 --replication-factor 1 --partitions 1
```

## Notes & troubleshooting

- If the consumer doesn't receive messages, ensure `spring.cloud.stream.kafka.binder.brokers` matches the advertised listener (localhost:9092).
- The Docker Compose uses `KAFKA_ADVERTISED_LISTENERS` with `PLAINTEXT_HOST://localhost:9092`. If running from Docker on a remote host, change the advertised hostname accordingly.

