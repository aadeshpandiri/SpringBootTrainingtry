package com.example.kafkademo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaStreamDemoApplication {
    public static void main(String[] args) {
        SpringApplication.run(KafkaStreamDemoApplication.class, args);
    }
}
