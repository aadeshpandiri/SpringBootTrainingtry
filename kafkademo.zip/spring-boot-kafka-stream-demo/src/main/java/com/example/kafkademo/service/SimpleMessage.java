package com.example.kafkademo.service;

import java.time.Instant;

public class SimpleMessage {
    private String id;
    private String payload;
    private Instant createdAt;

    public SimpleMessage() {}

    public SimpleMessage(String id, String payload) {
        this.id = id;
        this.payload = payload;
        this.createdAt = Instant.now();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPayload() {
        return payload;
    }

    public void setPayload(String payload) {
        this.payload = payload;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }
}
