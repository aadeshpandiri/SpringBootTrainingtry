package com.example.kafkademo.controller;

import com.example.kafkademo.service.MessageStore;
import com.example.kafkademo.service.SimpleMessage;
import org.springframework.cloud.stream.function.StreamBridge;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/messages")
public class MessageController {

    private final StreamBridge streamBridge;
    private final MessageStore messageStore;

    public MessageController(StreamBridge streamBridge, MessageStore messageStore) {
        this.streamBridge = streamBridge;
        this.messageStore = messageStore;
    }

    // Publish a message to Kafka (via Spring Cloud Stream's StreamBridge)
    @PostMapping("/publish")
    public ResponseEntity<SimpleMessage> publish(@RequestBody SimpleMessage payload) {
        if (payload.getId() == null || payload.getId().isEmpty()) {
            payload.setId(UUID.randomUUID().toString());
        }
        // send to binding name 'publish-out-0' (configured in application.properties)
        boolean ok = streamBridge.send("publish-out-0", payload);
        if (!ok) {
            return ResponseEntity.status(500).build();
        }
        return ResponseEntity.ok(payload);
    }

    @GetMapping("/received")
    public ResponseEntity<List<SimpleMessage>> received() {
        return ResponseEntity.ok(messageStore.getAll());
    }

    @PostMapping("/received/clear")
    public ResponseEntity<Void> clearReceived() {
        messageStore.clear();
        return ResponseEntity.noContent().build();
    }
}
