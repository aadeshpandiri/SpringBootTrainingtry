package com.example.kafkademo.service;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.function.Consumer;

@Configuration
public class MessageConsumerConfig {

    private final MessageStore messageStore;

    public MessageConsumerConfig(MessageStore messageStore) {
        this.messageStore = messageStore;
    }

    @Bean
    public Consumer<SimpleMessage> messageConsumer() {
        return msg -> {
            System.out.println("[Consumer] Received message: " + msg.getPayload());
            messageStore.add(msg);
        };
    }
}
