package com.example.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/calci")
public class CalciController {
	
	//http://localhost:8080/calci/add/10/20 - Path Param
	@GetMapping("/add/{num1}/{num2}")
	public int doAddition(@PathVariable int num1, @PathVariable int num2) {
		return(num1+num2);
	}
	
	//http://localhost:8080/calci/add?num1=10&num2=20 - Query Paramer
	//@GetMapping("/add")
	//public int add(@RequestParam int num1, @RequestParam int num2) {
		//return(num1+num2);
	//}

}





