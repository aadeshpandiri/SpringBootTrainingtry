package com.example.service;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

import org.springframework.stereotype.Service;

/**
 * Service class to simulate external service calls that might fail.
 */
@Service
public class SampleService {

    private static final String SAMPLE_SERVICE = "sampleService";
    private static final String SAMPLE_RETRY = "sampleRetry";

    /**
     * Simulates a service call that might fail.
     * @return Response from the external service or throws an exception
     */
   // @CircuitBreaker(name = SAMPLE_SERVICE, fallbackMethod = "fallbackResponse")
    @Retry(name = SAMPLE_RETRY, fallbackMethod = "fallbackAfterRetry")
    public String callExternalService() {
        // Simulating a random failure
        if (Math.random() > 0.5) {
            throw new RuntimeException("Service failed");
        }
        return "Service call succeeded";
    }

    /**
     * Fallback method called when the circuit breaker is open.
     * @param ex Exception thrown
     * @return Fallback response
     */
    public String fallbackResponse(Exception ex) {
        return "Fallback response: " + ex.getMessage();
    }
    private String fallbackAfterRetry(Throwable t) {
        return "Retry failed after multiple attempts: " + t.getMessage();
    }
}