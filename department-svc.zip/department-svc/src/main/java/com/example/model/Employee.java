package com.example.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Setter
@Getter
public class Employee {
    private Long id;
    private String name;
    private String department;

    // Constructors, getters, and setters
}