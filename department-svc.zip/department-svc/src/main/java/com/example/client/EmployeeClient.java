package com.example.client;



import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.model.Employee;

import java.util.List;

//@FeignClient(name = "employee-service", url = "${employee.service.url}")
//@FeignClient(name = "employee-service")
public interface EmployeeClient {

    //@GetMapping
    List<Employee> getAllEmployees();

    //@GetMapping("/employees/{id}")
    Employee getEmployeeById(@PathVariable("id") Long id);
}