package com.example.client;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.example.model.Employee;

import reactor.core.publisher.Mono;


//@Service
public class EmployeeClientWebClient {    
    
  //  @Autowired
    private WebClient.Builder webClientBuilder;
    
    public Employee getEmployeeById(Long id) {
        return webClientBuilder.build()
                .get()
                .uri("http://localhost:7878/employees/" + id)
                .retrieve()
                .bodyToMono(Employee.class).block();
    }
    
}