package com.example.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.example.client.EmployeeClient;
import com.example.client.EmployeeClientRestTemplate;
import com.example.client.EmployeeClientWebClient;
import com.example.model.Employee;

import reactor.core.publisher.Mono;

import java.util.List;

@Service
public class DepartmentService {
	
   // @Autowired
   // private  EmployeeClient employeeClient;
    @Autowired
    private  EmployeeClientRestTemplate employeeClientRestTemplate;
    
    //@Autowired
    //private  EmployeeClientWebClient employeeClientWebClient;


    

    
    
    //public List<Employee> getAllEmployees() {
     //   return employeeClient.getAllEmployees();
       
        
   // }

    public Employee getEmployeeById(Long id) {
        //return employeeClient.getEmployeeById(id);
       return employeeClientRestTemplate.getEmployeeById(id);
       //return employeeClientWebClient.getEmployeeById(id);

        
    }
}