package com.bezkoder.spring.swagger;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootSwagger3ExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
