# Spring Boot ControllerAdvice Exception Handling Demo (Spring Boot 3.5.x)

This project demonstrates exception handling in Spring MVC using `@ControllerAdvice` and `@ExceptionHandler`.

## What you'll find
- `GlobalExceptionHandler` (`@ControllerAdvice`) handling:
  - `ResourceNotFoundException` -> 404 Not Found
  - `MethodArgumentNotValidException` -> 400 Bad Request with field errors
  - Generic `Exception` -> 500 Internal Server Error
- `UserController` with endpoints to trigger the above cases
- `ErrorResponse` DTO used as standard error payload
- Postman collection with scenarios to reproduce and test behaviors

## Run
```bash
mvn clean package
mvn spring-boot:run
```
App runs at `http://localhost:8080`.

## Endpoints
- `GET /api/users/{id}` - returns user or throws `ResourceNotFoundException` (404)
- `POST /api/users` - create user (request body validated; invalid -> 400)
  - Example valid body: `{ "name": "Charlie" }`
- `GET /api/users/error-demo` - intentionally throws an exception (500)

## Expected error payload (example)
```json
{
  "timestamp": "2025-10-14T12:00:00",
  "status": 404,
  "error": "Not Found",
  "message": "User with id 99 not found",
  "path": "/api/users/99"
}
```

## Postman collection
Import `postman_exception_demo_collection.json` into Postman. Use collection variable `baseUrl` (default: `http://localhost:8080`).


