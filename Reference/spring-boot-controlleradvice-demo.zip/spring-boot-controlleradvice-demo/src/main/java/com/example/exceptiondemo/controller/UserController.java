package com.example.exceptiondemo.controller;

import com.example.exceptiondemo.exception.ResourceNotFoundException;
import com.example.exceptiondemo.model.User;
import com.example.exceptiondemo.model.UserRequest;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

@RestController
@RequestMapping("/api/users")
public class UserController {

    private final Map<Long, User> db = new HashMap<>();
    private final AtomicLong idGen = new AtomicLong(2);

    public UserController() {
        db.put(1L, new User(1L, "Alice"));
        db.put(2L, new User(2L, "Bob"));
    }

    @GetMapping("/{id}")
    public ResponseEntity<User> getUser(@PathVariable Long id) {
        User user = db.get(id);
        if (user == null) {
            throw new ResourceNotFoundException("User with id " + id + " not found");
        }
        return ResponseEntity.ok(user);
    }

    @PostMapping
    public ResponseEntity<User> createUser(@Valid @RequestBody UserRequest req) {
        long newId = idGen.incrementAndGet();
        User user = new User(newId, req.getName());
        db.put(newId, user);
        return ResponseEntity.ok(user);
    }

    // endpoint to demonstrate generic exception (division by zero)
    @GetMapping("/error-demo")
    public ResponseEntity<String> errorDemo() {
        int x = 1 / 0; // will cause ArithmeticException
        return ResponseEntity.ok("ok");
    }
}
