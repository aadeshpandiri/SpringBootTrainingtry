# ELK & Zipkin Docker Stack (Micrometer Edition)

This directory contains the Docker Compose setup for running:
- **Zipkin** (port 9411) for distributed tracing collection via Micrometer Brave exporter.
- **Elasticsearch** (port 9200) for storing logs and trace data.
- **Logstash** (port 5000) for ingesting JSON logs with trace/span IDs.
- **Kibana** (port 5601) for visualizing logs and Zipkin traces side-by-side.

## Prerequisites

- Docker
- Docker Compose
- Microservice demos built with Micrometer Tracing (via `micrometer-tracing-exporter-zipkin`)

## Running the Stack

1. Navigate to this directory:
   ```bash
   cd elk-zipkin-stack-micrometer
   ```
2. Start all services:
   ```bash
   docker-compose up -d
   ```
3. Verify services:
   - Zipkin UI: http://localhost:9411
   - Elasticsearch: http://localhost:9200
   - Kibana: http://localhost:5601

## Stopping the Stack

```bash
docker-compose down
```
