package com.example.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.beans.factory.annotation.Autowired;

@RestController
@CrossOrigin("*")
public class AController {
// Trace-aware RestTemplate calls
    @Autowired
    private RestTemplate restTemplate;

    @GetMapping("/a")
    public String callNext() {
        return restTemplate.getForObject("http://localhost:8082/b", String.class);
    	//return "a";
    }
}
