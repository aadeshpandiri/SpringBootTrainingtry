package com.example.serviceb;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.beans.factory.annotation.Autowired;

@RestController
public class BController {
// Trace-aware RestTemplate calls
    @Autowired
    private RestTemplate restTemplate;

    @GetMapping("/b")
    public String callNext() {
        return restTemplate.getForObject("http://localhost:8083/c", String.class);
    }
}
