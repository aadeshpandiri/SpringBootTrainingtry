# service-b-micrometer

## Prerequisites
- Java 17+
- Maven 3.6+
- ELK & Zipkin stack running (method in elk-zipkin-stack-micrometer README)

## Running the Service
```bash
cd service-b-micrometer
mvn clean spring-boot:run
```
## Testing the Endpoint
```bash
curl http://localhost:8082/b
```

